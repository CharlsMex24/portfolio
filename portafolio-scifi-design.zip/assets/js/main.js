/* ── BOOT SEQUENCE ────────────────────────────────────────────────────── */
(function(){
    const overlay = document.getElementById('boot-overlay');
    if(!overlay) return;

    document.body.style.overflow = 'hidden';

    const linesEl = document.getElementById('boot-lines');
    const barEl   = document.getElementById('boot-bar');

    const seq = [
        { t:0,    text:'SYS:// CARLOS VELASCO · PORTFOLIO v2.0.26',  cls:'boot-h'  },
        { t:180,  text:'──────────────────────────────────────────',  cls:'boot-d'  },
        { t:420,  text:'> Booting neural interface...',               cls:'boot-n'  },
        { t:900,  text:'  ✓ Interface online',                        cls:'boot-ok' },
        { t:1100, text:'> Loading mechatronics stack...',             cls:'boot-n'  },
        { t:1560, text:'  ✓ AI · Robotics · Embedded',                cls:'boot-ok' },
        { t:1760, text:'> Syncing competition records...',            cls:'boot-n'  },
        { t:2240, text:'  ✓ Shell Eco-marathon  2× 2nd place',        cls:'boot-ok' },
        { t:2440, text:'> Calibrating AI subsystems...',              cls:'boot-n'  },
        { t:2900, text:'  ✓ Accuracy: 94.3% — GPU ready',             cls:'boot-ok' },
        { t:3100, text:'──────────────────────────────────────────',  cls:'boot-d'  },
        { t:3300, text:'  SYSTEM READY · BIENVENIDO, CARLOS',         cls:'boot-h'  },
    ];

    let gone = false;
    function dismiss(){
        if(gone) return; gone = true;
        overlay.style.transition = 'transform 0.9s cubic-bezier(.76,0,.24,1), opacity 0.7s ease';
        overlay.style.transform  = 'translateY(-100%)';
        overlay.style.opacity    = '0';
        setTimeout(() => { overlay.remove(); document.body.style.overflow = ''; }, 1000);
    }

    document.addEventListener('keydown', dismiss, { once: true });
    overlay.addEventListener('click', dismiss);

    seq.forEach((item, i) => {
        setTimeout(() => {
            const el = document.createElement('div');
            el.className = 'boot-line ' + item.cls;
            el.textContent = item.text;
            linesEl.appendChild(el);
            barEl.style.width = ((i + 1) / seq.length * 100) + '%';
        }, item.t);
    });

    setTimeout(dismiss, seq[seq.length - 1].t + 1400);
})();


/* ── THREE.JS PARTICLE SPHERE ─────────────────────────────────────────── */
(function(){
    if(typeof THREE === 'undefined') return;
    const container = document.getElementById('three-hero');
    if(!container) return;

    const W = container.clientWidth  || 500;
    const H = container.clientHeight || 520;

    const scene    = new THREE.Scene();
    const camera   = new THREE.PerspectiveCamera(55, W/H, 0.1, 2000);
    camera.position.z = 340;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(W, H);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0x000000, 0);
    container.appendChild(renderer.domElement);

    /* ── Main sphere — 3200 particles (Fibonacci distribution) ── */
    const COUNT = 3200;
    const pos   = new Float32Array(COUNT * 3);
    const col   = new Float32Array(COUNT * 3);

    for(let i = 0; i < COUNT; i++){
        const phi   = Math.acos(1 - 2*(i + 0.5)/COUNT);
        const theta = Math.PI * (1 + Math.sqrt(5)) * i;
        const r     = 130 + (Math.random() - 0.5) * 24;

        pos[i*3]   = r * Math.sin(phi) * Math.cos(theta);
        pos[i*3+1] = r * Math.sin(phi) * Math.sin(theta);
        pos[i*3+2] = r * Math.cos(phi);

        /* cyan (#00c8ff) at top → purple (#8b5cf6) at bottom */
        const t = (pos[i*3+1] / 130 + 1) / 2;
        col[i*3]   = (1-t)*0.0   + t*0.545;
        col[i*3+1] = (1-t)*0.784 + t*0.361;
        col[i*3+2] = (1-t)*1.0   + t*0.965;
    }

    const sphereGeo = new THREE.BufferGeometry();
    sphereGeo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    sphereGeo.setAttribute('color',    new THREE.BufferAttribute(col, 3));
    const sphereMat = new THREE.PointsMaterial({
        size: 1.6, vertexColors: true,
        transparent: true, opacity: 0.82, sizeAttenuation: true,
    });
    const sphere = new THREE.Points(sphereGeo, sphereMat);
    scene.add(sphere);

    /* ── Inner glow core ── */
    const INNER  = 300;
    const innerP = new Float32Array(INNER * 3);
    for(let i = 0; i < INNER; i++){
        const r   = Math.random() * 55;
        const phi = Math.random() * Math.PI * 2;
        const th  = Math.acos(2*Math.random() - 1);
        innerP[i*3]   = r * Math.sin(th) * Math.cos(phi);
        innerP[i*3+1] = r * Math.sin(th) * Math.sin(phi);
        innerP[i*3+2] = r * Math.cos(th);
    }
    const innerGeo = new THREE.BufferGeometry();
    innerGeo.setAttribute('position', new THREE.BufferAttribute(innerP, 3));
    const innerMat = new THREE.PointsMaterial({ size:1.1, color:0x00c8ff, transparent:true, opacity:0.35 });
    const innerSphere = new THREE.Points(innerGeo, innerMat);
    scene.add(innerSphere);

    /* ── Orbital rings ── */
    function makeRing(radius, tiltX, tiltZ, color, count){
        const geo = new THREE.BufferGeometry();
        const p   = new Float32Array(count * 3);
        for(let i = 0; i < count; i++){
            const a = (i/count) * Math.PI * 2;
            p[i*3]   = radius * Math.cos(a);
            p[i*3+1] = 0;
            p[i*3+2] = radius * Math.sin(a);
        }
        geo.setAttribute('position', new THREE.BufferAttribute(p, 3));
        const mat  = new THREE.PointsMaterial({ size:0.9, color, transparent:true, opacity:0.4 });
        const ring = new THREE.Points(geo, mat);
        ring.rotation.x = tiltX;
        ring.rotation.z = tiltZ;
        return ring;
    }
    const ring1 = makeRing(158,  0.4,  0.1, 0x00c8ff, 200);
    const ring2 = makeRing(170, -0.8,  0.3, 0x8b5cf6, 160);
    const ring3 = makeRing(180,  1.2, -0.2, 0x6366f1, 120);
    scene.add(ring1); scene.add(ring2); scene.add(ring3);

    /* ── Mouse reactive tilt ── */
    let mx = 0, my = 0, tx = 0, ty = 0;
    document.addEventListener('mousemove', e => {
        mx = (e.clientX / window.innerWidth  - 0.5) * 1.0;
        my = (e.clientY / window.innerHeight - 0.5) * 0.55;
    });

    /* ── Animate ── */
    let time = 0;
    (function animate(){
        requestAnimationFrame(animate);
        time += 0.004;

        tx += (mx - tx) * 0.04;
        ty += (my - ty) * 0.04;

        sphere.rotation.y      =  time * 0.25 + tx;
        sphere.rotation.x      =  ty * 0.6;
        innerSphere.rotation.y = -time * 0.5;
        innerSphere.rotation.x =  time * 0.2;

        ring1.rotation.y = time * 0.25 + tx;
        ring2.rotation.y = time * 0.25 + tx;
        ring3.rotation.y = time * 0.25 + tx;
        ring1.rotation.z =  time * 0.55;
        ring2.rotation.z = -time * 0.38;
        ring3.rotation.z =  time * 0.28;

        sphereMat.opacity = 0.72 + Math.sin(time * 1.8) * 0.1;

        renderer.render(scene, camera);
    })();

    /* ── Resize ── */
    window.addEventListener('resize', () => {
        const nW = container.clientWidth;
        const nH = container.clientHeight;
        camera.aspect = nW / nH;
        camera.updateProjectionMatrix();
        renderer.setSize(nW, nH);
    });
})();


/* ── PARTICLE CANVAS (background) ────────────────────────────────────── */
(function(){
    const canvas = document.getElementById('hero-canvas');
    if(!canvas) return;
    const ctx = canvas.getContext('2d');
    let W, H, particles, mouse = { x:-9999, y:-9999 };

    const hint = document.getElementById('netHint');
    function hideHint(){ if(hint && !hint.classList.contains('is-hidden')) hint.classList.add('is-hidden'); }
    if(hint){
        const hero = document.getElementById('home');
        if(hero){
            hero.addEventListener('mousemove', hideHint, { once:true });
            hero.addEventListener('touchstart', hideHint, { once:true, passive:true });
